-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2017 at 12:49 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evsdatabase`
--
CREATE DATABASE IF NOT EXISTS `evsdatabase` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `evsdatabase`;

-- --------------------------------------------------------

--
-- Table structure for table `mailinglist`
--

CREATE TABLE `mailinglist` (
  `RegistrationNumber` int(11) NOT NULL,
  `Constituency` varchar(100) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `TimeOfRegistration` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mailinglist`
--

INSERT INTO `mailinglist` (`RegistrationNumber`, `Constituency`, `Password`, `TimeOfRegistration`) VALUES
(814001534, 'St. Andrew South East', 'bA03iHq1Mt', '2017-03-12 06:55:19');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `RegistrationNumber` int(11) NOT NULL,
  `Surname` varchar(100) NOT NULL,
  `GivenNames` varchar(200) NOT NULL,
  `Sex` varchar(10) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `CountryOfBirth` varchar(200) NOT NULL,
  `DateIssued` date NOT NULL,
  `ExpireDate` date NOT NULL,
  `HeightFeet` int(11) NOT NULL,
  `HeightInches` int(11) NOT NULL,
  `Voted` int(11) NOT NULL DEFAULT '0',
  `Constituency` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Phone` varchar(200) NOT NULL,
  `E-Mail` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`RegistrationNumber`, `Surname`, `GivenNames`, `Sex`, `DateOfBirth`, `CountryOfBirth`, `DateIssued`, `ExpireDate`, `HeightFeet`, `HeightInches`, `Voted`, `Constituency`, `Password`, `Phone`, `E-Mail`) VALUES
(814001534, 'Ahmad', 'Aadam', 'Male', '1995-12-04', 'Trinidad', '2009-09-26', '2025-04-28', 5, 6, 0, 'St. Andrew South East', '51fed70094fe9b0dd6a96aa5268cc1d6fcf3c587', '1 (868) 293-1958', 'aadamahmad13@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `Constituency` varchar(100) NOT NULL,
  `NDC` int(11) NOT NULL DEFAULT '0',
  `NNP` int(11) NOT NULL DEFAULT '0',
  `NNPTraditional` int(11) NOT NULL DEFAULT '0',
  `NDCTraditional` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`Constituency`, `NDC`, `NNP`, `NNPTraditional`, `NDCTraditional`) VALUES
('St. Andrew North East', 0, 0, 0, 0),
('St. Andrew North West', 0, 0, 0, 0),
('St. Andrew South East', 0, 0, 0, 0),
('St. Andrew South West', 0, 0, 0, 0),
('St. David', 0, 0, 0, 0),
('St. George North East', 0, 0, 0, 0),
('St. George North West', 0, 1, 0, 0),
('St. George South', 0, 0, 0, 0),
('St. George South East', 0, 0, 0, 0),
('St. John', 0, 0, 0, 0),
('St. Mark', 0, 0, 0, 0),
('St. Patrick East', 0, 0, 0, 0),
('St. Patrick West', 0, 0, 0, 0),
('Town of St. George', 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mailinglist`
--
ALTER TABLE `mailinglist`
  ADD PRIMARY KEY (`RegistrationNumber`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`RegistrationNumber`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`Constituency`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
