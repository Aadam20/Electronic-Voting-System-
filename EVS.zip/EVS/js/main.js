"use strict"

$(document).ready(function(){
  console.log("All elements loaded");
  //Client Page JQuery Functions
  hideForms();

  $("#sideMenu").click(openMenu);
  $("#register_button").click(displayRegistration);
  $("#content_button").click(displayContent);
  $("#vote_button").click(displayVote);
  $("#scan_portrait").click(scanPortrait);
  $("#verify_portrait").click(verifyPortrait);
  $("#swap_camera").click(switchToCamera);
  $("#save_snapshot").click(completeRegistration); //Will be changed to KairosEnroll once database is established.


  $("#K_hack").click(KairosRemove);

  loadConstituencies();

});

/*CLIENT FUNCTIONS DEFINES*/

function hideForms(){

  $("#K_hack").hide();

  $("#Login").hide();
  $("#image_capture").hide();
  $("#Registration").hide();
  $("#swap_camera").hide();
  $("#save_snapshot").hide();
  $("#scan_portrait").hide();
  $("#verify_portrait").hide();
}


function displayCapture(){
  $("#image_capture").show(500);
  $("#Login").hide(500);
  $("#Registration").hide(500);
}

function displayVote(){
  $("#Login").show(500);
  $("#Registration").hide(500);
  $("#Content").hide(500);
  $("#image_capture").hide(500);
  $("#scan_portrait").hide(100);
  $("#verify_portrait").hide(100);
}

function displayRegistration(){
  $("#Registration").show(500);
  $("#Content").hide(500);
  $("#Login").hide(500);
  $("#image_capture").hide(500);
  $("#scan_portrait").hide(100);
  $("#verify_portrait").hide(100);
}

function displayContent(){
  $("#Content").show(500);
  $("#Registration").hide(500);
  $("#Login").hide(500);
  $("#image_capture").hide(500);
  $("#scan_portrait").hide(100);
  $("#verify_portrait").hide(100);
}

function switchToCamera(){

  $("#snap_shot").fadeOut();
  $("#camera").fadeIn(700);
  $("#swap_camera").hide(400);
  $("#save_snapshot").hide(400);

}

function scanPortrait(){

  takeSnapShot();
  $("#camera").slideUp(400);
  $("#snap_shot").fadeIn(500);
  KairosDetect();

}

function verifyPortrait(){

    takeSnapShot();
    $("#camera").slideUp(400);
    $("#snap_shot").fadeIn(500);
    VerifyByKairos();

}

function openMenu(){

  $("#Menu").css("width", "200px");
  $("#main").css("margin-left", "200px");

}

function closeMenu(){

  $("#Menu").css("width", "0");
  $("#main").css("margin-left", "0");

}

function login(){

      var LoginRegistration = $("#user").val();
      var password = $("#pass").val();

      var loginData = {

        'RegistrationNumber': LoginRegistration,
        'Password': password

      };

      $.ajax({

        type: "POST",
        url: '/EVS/communication/VotingProcess.php',
        data: loginData,
        async : false,

        success: function(loginSuccess){

            if(loginSuccess == 1){
              swal("E.V.S Response", "Login Successful", "success");
              $("#verify_portrait").show(200)
              displayCapture();
            }
            else
            if(loginSuccess == 0){
              swal("E.V.S Response", "Login Error\nPlease Ensure Registration Number and Password\n are entered correctly.", "error");
            }
            else
            if(loginSuccess == -1){
              swal("E.V.S Response", "Users are allowed to vote only ONCE.\n continued attempts to login is punishable by the law.", "warning");
            }
            else{
              swal("E.V.S Response", "Cannot Connect to Database\n Please ensure device is connected to the internet.", "error");
            }

        }

      });

      return false;

}

function loadConstituencies(){

    $.get("/EVS/communication/ConstituencyStartup.php",function(cons){

          //console.log(cons);

          if ($("#Constituency").length > 0){
                cons.forEach(function(constituency){
                  var htmlStr = "<option value='"+constituency+"'>"+constituency+"</option>";
                  $("#Constituency").append(htmlStr);
                })
              }

    }, "json");


}

function register() {

  var constituency = $("#Constituency").val();
  var sex = $("input[name=Sex]:checked").val();

  var data = {

    'Constituency' : constituency,
    'Sex' : sex,
    'Function' : "check"

  };


  console.log(data);

  $.ajax({

      type: "POST",
      url: '/EVS/communication/RegisterVoter.php',
      data: data,
      async : false,

      success: function(check){
        console.log(check);
        if(check == 1){
          swal("E.V.S Response", "Information Verified.", "success");
          $("#scan_portrait").show(200);
          displayCapture();
        }
        else
        if(check == -1){
          swal("E.V.S Response", "Please ensure Constituency and Sex are appropriately Selected.", "error");
        }
        else{
          swal("E.V.S Response", "Databse Could Not Be Accessed.\n Please ensure device is connected to the Internet.", "error");
        }

      }

  });

  return false;
}

function completeRegistration(){

  swal({
    title: "E.V.S Confimation",
    text: "Please Confirm that all Information was Entered Correctly\n Before Proceeding",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3076da",
    confirmButtonText: "Confirm",
    closeOnConfirm: false
    },
    function(){
      KairosEnroll();
  });

}

function clearLogin(){
  $("#user").val("");
  $("#pass").val("");
}

function clearRegistration() {
  $("#RegistrationNumber").val("");
  $("#Constituency").val(0);
  $("#Surname").val("");
  $("#GivenNames").val("");
  $("#DateOfBirth").val("");
  $("#CountryOfBirth").val("");
  $("#DateIssued").val("");
  $("#ExpireDate").val("");
  $("#HeightFeet").val("");
  $("#HeightInches").val("");
  $("input[name=Sex]:checked").val("");
}
